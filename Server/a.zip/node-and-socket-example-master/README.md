node-and-socket-example
=======================

A quick example of using node.js with socket.io